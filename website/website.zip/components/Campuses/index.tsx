import React from 'react'
import { Children } from 'react';
import { useEffect, useState } from "react";


const campuses = () => {

      
      



  return (
      <>
    <section>
            <div className='container-fluid bg-dark'>
                  <h1 className='text-center'> EXPLORER OUR DEIFFERENT CAMPUSES </h1>
            </div>
            

      </section>
      
      </>
    
  )
}

export default campuses