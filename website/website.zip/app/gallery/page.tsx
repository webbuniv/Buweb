import React from 'react'
import UniversityGallery from '@/components/Gallery/gallery'

const Gallery = () => {
  return (
    <div className=' bg-gray-500'>
        <UniversityGallery/>
    </div>
  )
}

export default Gallery